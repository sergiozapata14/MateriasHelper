package com.cc.carrerashelper;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class materias extends AppCompatActivity
{
    TextView ver_nombre, ver_clave, ver_semestre, ver_periodo, ver_pre;
    Button box1, box2, box3, box4, box5, box6, box7, box8, box9, box10, box11, box12, box13, box14, box15,
            box16, box17, box18, box19, box20, box21, box22, box23, box24, box25, box26, box27, box28, box29, box30,
            box31, box32, box33, box34, box35, box36, box37, box38, box39, box40, box41, box42, box43, box44, box45,
            box46, box47, box48, box49, box50, box51, box52, box53, box54, box55, box56, box57, box58;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_materias);
        box1 = (Button) findViewById(R.id.checkBox1);
        box2 = (Button) findViewById(R.id.checkBox2);
        box3 = (Button) findViewById(R.id.checkBox3);
        box4 = (Button) findViewById(R.id.checkBox4);
        box5 = (Button) findViewById(R.id.checkBox5);
        box6 = (Button) findViewById(R.id.checkBox6);
        box7 = (Button) findViewById(R.id.checkBox7);
        box8 = (Button) findViewById(R.id.checkBox8);
        box9 = (Button) findViewById(R.id.checkBox9);
        box10 = (Button) findViewById(R.id.checkBox10);
        box11 = (Button) findViewById(R.id.checkBox11);
        box12 = (Button) findViewById(R.id.checkBox12);
        box13 = (Button) findViewById(R.id.checkBox13);
        box14 = (Button) findViewById(R.id.checkBox14);
        box15 = (Button) findViewById(R.id.checkBox15);
        box16 = (Button) findViewById(R.id.checkBox16);
        box17 = (Button) findViewById(R.id.checkBox17);
        box18 = (Button) findViewById(R.id.checkBox18);
        box19 = (Button) findViewById(R.id.checkBox19);
        box20 = (Button) findViewById(R.id.checkBox20);
        box21 = (Button) findViewById(R.id.checkBox21);
        box22 = (Button) findViewById(R.id.checkBox22);
        box23 = (Button) findViewById(R.id.checkBox23);
        box24 = (Button) findViewById(R.id.checkBox24);
        box25 = (Button) findViewById(R.id.checkBox25);
        box26 = (Button) findViewById(R.id.checkBox26);
        box27 = (Button) findViewById(R.id.checkBox27);
        box28 = (Button) findViewById(R.id.checkBox28);
        box29 = (Button) findViewById(R.id.checkBox29);
        box30 = (Button) findViewById(R.id.checkBox30);
        box31 = (Button) findViewById(R.id.checkBox31);
        box32 = (Button) findViewById(R.id.checkBox32);
        box33 = (Button) findViewById(R.id.checkBox33);
        box34 = (Button) findViewById(R.id.checkBox34);
        box35 = (Button) findViewById(R.id.checkBox35);
        box36 = (Button) findViewById(R.id.checkBox36);
        box37 = (Button) findViewById(R.id.checkBox37);
        box38 = (Button) findViewById(R.id.checkBox38);
        box39 = (Button) findViewById(R.id.checkBox39);
        box40 = (Button) findViewById(R.id.checkBox40);
        box41 = (Button) findViewById(R.id.checkBox41);
        box42 = (Button) findViewById(R.id.checkBox42);
        box43 = (Button) findViewById(R.id.checkBox43);
        box44 = (Button) findViewById(R.id.checkBox44);
        box45 = (Button) findViewById(R.id.checkBox45);
        box46 = (Button) findViewById(R.id.checkBox46);
        box47 = (Button) findViewById(R.id.checkBox47);
        box48 = (Button) findViewById(R.id.checkBox48);
        box49 = (Button) findViewById(R.id.checkBox49);
        box50 = (Button) findViewById(R.id.checkBox50);
        box51 = (Button) findViewById(R.id.checkBox51);
        box52 = (Button) findViewById(R.id.checkBox52);
        box53 = (Button) findViewById(R.id.checkBox53);
        box54 = (Button) findViewById(R.id.checkBox54);
        box55 = (Button) findViewById(R.id.checkBox55);
        box56 = (Button) findViewById(R.id.checkBox56);
        box57 = (Button) findViewById(R.id.checkBox57);
        box58 = (Button) findViewById(R.id.checkBox58);
        ver_nombre = (TextView) findViewById(R.id.ViewNombre);
        ver_clave = (TextView) findViewById(R.id.ViewClave);
        ver_semestre = (TextView) findViewById(R.id.ViewSemestre);
        ver_periodo = (TextView) findViewById(R.id.ViewPeriodo);
        ver_pre = (TextView) findViewById(R.id.ViewPrerequisitos);
        box1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox1)
                {
                    ver_nombre.setText("Inglés básico");
                    ver_clave.setText("Clave: ING101");
                    ver_semestre.setText("Semestre: 0");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox2)
                {
                    ver_nombre.setText("Inglés intermedio bajo");
                    ver_clave.setText("Clave: ING102");
                    ver_semestre.setText("Semestre: 0");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Inglés básico");
                }
            }
        });
        box3.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox3)
                {
                    ver_nombre.setText("Física básica");
                    ver_clave.setText("Clave: FIS020");
                    ver_semestre.setText("Semestre: 0");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box4.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox4)
                {
                    ver_nombre.setText("Fundamentos matemáticos universitarios");
                    ver_clave.setText("Clave: MIN001");
                    ver_semestre.setText("Semestre: 0");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box5.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox5)
                {
                    ver_nombre.setText("Fundamentos del pensamiento crítico y humanista");
                    ver_clave.setText("Clave: FIL016");
                    ver_semestre.setText("Semestre: 1");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box6.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox6)
                {
                    ver_nombre.setText("Optativa de lengua y cultura I");
                    ver_clave.setText("Clave: OPI001");
                    ver_semestre.setText("Semestre: 1");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Inglés intermedio bajo");
                }
            }
        });
        box7.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox7)
                {
                    ver_nombre.setText("Matemáticas para la computación");
                    ver_clave.setText("Clave: ICS001");
                    ver_semestre.setText("Semestre: 1");
                    ver_periodo.setText("Disponibilidad: Solo en otoño");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box8.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox8)
                {
                    ver_nombre.setText("Fundamentos de programación");
                    ver_clave.setText("Clave: LTI002");
                    ver_semestre.setText("Semestre: 1");
                    ver_periodo.setText("Disponibilidad: Solo en otoño");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box9.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox9)
                {
                    ver_nombre.setText("Introducción a las tecnologías de información");
                    ver_clave.setText("Clave: LTI100");
                    ver_semestre.setText("Semestre: 1");
                    ver_periodo.setText("Disponibilidad: Solo en otoño");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box10.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox10)
                {
                    ver_nombre.setText("Herramientas y comunidad digital");
                    ver_clave.setText("Clave: COM013");
                    ver_semestre.setText("Semestre: 2");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box11.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox11)
                {
                    ver_nombre.setText("Persona y cultura humanista");
                    ver_clave.setText("Clave: FHU004");
                    ver_semestre.setText("Semestre: 2");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Fundamentos del pensamiento crítico y humanista");
                }
            }
        });
        box12.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox12)
                {
                    ver_nombre.setText("Optativa de lengua y cultura II");
                    ver_clave.setText("Clave: OPI002");
                    ver_semestre.setText("Semestre: 2");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Optativa de lengua y cultura I");
                }
            }
        });
        box13.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox13)
                {
                    ver_nombre.setText("Estructura de datos");
                    ver_clave.setText("Clave: LTI003");
                    ver_semestre.setText("Semestre: 2");
                    ver_periodo.setText("Disponibilidad: Solo en primavera");
                    ver_pre.setText("Pre-requisitos: Matemáticas para la computación y Fundamentos de programación");
                }
            }
        });
        box14.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox14)
                {
                    ver_nombre.setText("Matemáticas I");
                    ver_clave.setText("Clave: MIN003");
                    ver_semestre.setText("Semestre: 2");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Fundamentos matemáticos universitarios");
                }
            }
        });
        box15.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox15)
                {
                    ver_nombre.setText("Fundamentos estructurales del pensamientos crítico");
                    ver_clave.setText("Clave: LPC001");
                    ver_semestre.setText("Semestre: 3");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Fundamentos del pensamiento crítico y humanista");
                }
            }
        });
        box16.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox16)
                {
                    ver_nombre.setText("Optativa de lengua y cultura III");
                    ver_clave.setText("Clave: OPI003");
                    ver_semestre.setText("Semestre: 3");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Optativa de lengua y cultura II");
                }
            }
        });
        box17.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox17)
                {
                    ver_nombre.setText("Matemáticas II");
                    ver_clave.setText("Clave: MIN004");
                    ver_semestre.setText("Semestre: 3");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Matemáticas I");
                }
            }
        });
        box18.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox18)
                {
                    ver_nombre.setText("Paradigmas de programación I");
                    ver_clave.setText("Clave: LTI004");
                    ver_semestre.setText("Semestre: 3");
                    ver_periodo.setText("Disponibilidad: Solo en otoño");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box19.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox19)
                {
                    ver_nombre.setText("Ingeniería de software");
                    ver_clave.setText("Clave: ISW100");
                    ver_semestre.setText("Semestre: 3");
                    ver_periodo.setText("Disponibilidad: Solo en otoño");
                    ver_pre.setText("Pre-requisitos: Estructura de datos");
                }
            }
        });
        box20.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox20)
                {
                    ver_nombre.setText("Base de datos");
                    ver_clave.setText("Clave: LTI015");
                    ver_semestre.setText("Semestre: 3");
                    ver_periodo.setText("Disponibilidad: Solo en otoño");
                    ver_pre.setText("Pre-requisitos: Estructura de datos");
                }
            }
        });
        box21.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox21)
                {
                    ver_nombre.setText("Sistemas operativos");
                    ver_clave.setText("Clave: LTI303");
                    ver_semestre.setText("Semestre: 3");
                    ver_periodo.setText("Disponibilidad: Solo en otoño");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box22.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox22)
                {
                    ver_nombre.setText("Servicio social");
                    ver_clave.setText("Clave: SSC003");
                    ver_semestre.setText("Semestre: 3");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box23.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox23)
                {
                    ver_nombre.setText("Optativa de lengua y cultura IV");
                    ver_clave.setText("Clave: OPI004");
                    ver_semestre.setText("Semestre: 4");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Optativa de lengua y cultura III");
                }
            }
        });
        box24.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox24)
                {
                    ver_nombre.setText("Probabilidad y estadística");
                    ver_clave.setText("Clave: MIN007");
                    ver_semestre.setText("Semestre: 4");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Fundamentos matemáticos universitarios");
                }
            }
        });
        box25.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox25)
                {
                    ver_nombre.setText("Paradigmas de programación II");
                    ver_clave.setText("Clave: LTI006");
                    ver_semestre.setText("Semestre: 4");
                    ver_periodo.setText("Disponibilidad: Solo en primavera");
                    ver_pre.setText("Pre-requisitos: Paradigmas de programación I");
                }
            }
        });
        box26.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox26)
                {
                    ver_nombre.setText("Modelo emprendedor");
                    ver_clave.setText("Clave: EMP001");
                    ver_semestre.setText("Semestre: 4");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box27.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox27)
                {
                    ver_nombre.setText("Base de datos avanzadas");
                    ver_clave.setText("Clave: LTI007");
                    ver_semestre.setText("Semestre: 4");
                    ver_periodo.setText("Disponibilidad: Solo en primavera");
                    ver_pre.setText("Pre-requisitos: Base de datos");
                }
            }
        });
        box28.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox28)
                {
                    ver_nombre.setText("Teoría de autómatas");
                    ver_clave.setText("Clave: LTI016");
                    ver_semestre.setText("Semestre: 4");
                    ver_periodo.setText("Disponibilidad: Solo en primavera");
                    ver_pre.setText("Pre-requisitos: Estructura de datos");
                }
            }
        });
        box29.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox29)
                {
                    ver_nombre.setText("Ingeniería de usabilidad");
                    ver_clave.setText("Clave: ISW210");
                    ver_semestre.setText("Semestre: 4");
                    ver_periodo.setText("Disponibilidad: Solo en primavera");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box30.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox30)
                {
                    ver_nombre.setText("Práctica profesional");
                    ver_clave.setText("Clave: PRA480");
                    ver_semestre.setText("Semestre: 4");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box31.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox31)
                {
                    ver_nombre.setText("Escritura académica");
                    ver_clave.setText("Clave: LPC002");
                    ver_semestre.setText("Semestre: 5");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Fundamentos estructurales del pensamiento crítico");
                }
            }
        });
        box32.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox32)
                {
                    ver_nombre.setText("Ética y responsabilidad social");
                    ver_clave.setText("Clave: FHU005");
                    ver_semestre.setText("Semestre: 5");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Persona y cultura humanista");
                }
            }
        });
        box33.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox33)
                {
                    ver_nombre.setText("Administración de proyectos");
                    ver_clave.setText("Clave: IND231");
                    ver_semestre.setText("Semestre: 5");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box34.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox34)
                {
                    ver_nombre.setText("Redes");
                    ver_clave.setText("Clave: ICS006");
                    ver_semestre.setText("Semestre: 5");
                    ver_periodo.setText("Disponibilidad: Solo en otoño");
                    ver_pre.setText("Pre-requisitos: Matemáticas II");
                }
            }
        });
        box35.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox35)
                {
                    ver_nombre.setText("Ingeniería de requerimientos");
                    ver_clave.setText("Clave: ISW200");
                    ver_semestre.setText("Semestre: 5");
                    ver_periodo.setText("Disponibilidad: Solo en otoño");
                    ver_pre.setText("Pre-requisitos: Ingeniería de software");
                }
            }
        });
        box36.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox36)
                {
                    ver_nombre.setText("Inteligencia artificial");
                    ver_clave.setText("Clave: ICS008");
                    ver_semestre.setText("Semestre: 5");
                    ver_periodo.setText("Disponibilidad: Solo en otoño");
                    ver_pre.setText("Pre-requisitos: Teoría de autómatas");
                }
            }
        });
        box37.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox37)
                {
                    ver_nombre.setText("Estadística aplicada");
                    ver_clave.setText("Clave: MIN008");
                    ver_semestre.setText("Semestre: 5");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Probabilidad y estadística");
                }
            }
        });
        box38.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox38)
                {
                    ver_nombre.setText("Optativa de formación humanista");
                    ver_clave.setText("Clave: OFH001");
                    ver_semestre.setText("Semestre: 6");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Ética y responsabilidad social");
                }
            }
        });
        box39.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox39)
                {
                    ver_nombre.setText("Sistemas distribuidos");
                    ver_clave.setText("Clave: ICS004");
                    ver_semestre.setText("Semestre: 6");
                    ver_periodo.setText("Disponibilidad: Solo en primavera");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box40.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox40)
                {
                    ver_nombre.setText("Administración ágil de proyectos de software");
                    ver_clave.setText("Clave: ISW201");
                    ver_semestre.setText("Semestre: 6");
                    ver_periodo.setText("Disponibilidad: Solo en primavera");
                    ver_pre.setText("Pre-requisitos: Ingeniería de requerimientos");
                }
            }
        });
        box41.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox41)
                {
                    ver_nombre.setText("Calidad de software");
                    ver_clave.setText("Clave: ISW204");
                    ver_semestre.setText("Semestre: 6");
                    ver_periodo.setText("Disponibilidad: Solo en primavera");
                    ver_pre.setText("Pre-requisitos: Paradigmas de programación II");
                }
            }
        });
        box42.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox42)
                {
                    ver_nombre.setText("Proceso personal de software I");
                    ver_clave.setText("Clave: ISW207");
                    ver_semestre.setText("Semestre: 6");
                    ver_periodo.setText("Disponibilidad: Solo en primavera");
                    ver_pre.setText("Pre-requisitos: Estadística aplicada");
                }
            }
        });
        box43.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox43)
                {
                    ver_nombre.setText("Desarrollo web");
                    ver_clave.setText("Clave: LTI009");
                    ver_semestre.setText("Semestre: 6");
                    ver_periodo.setText("Disponibilidad: Solo en primavera");
                    ver_pre.setText("Pre-requisitos: Base de datos avanzadas");
                }
            }
        });
        box44.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox44)
                {
                    ver_nombre.setText("Optativa (línea electiva)");
                    ver_clave.setText("Clave: OSW001");
                    ver_semestre.setText("Semestre: 6");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box45.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox45)
                {
                    ver_nombre.setText("Seguridad informática");
                    ver_clave.setText("Clave: ICS007");
                    ver_semestre.setText("Semestre: 7");
                    ver_periodo.setText("Disponibilidad: Solo en otoño");
                    ver_pre.setText("Pre-requisitos: Redes");
                }
            }
        });
        box46.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox46)
                {
                    ver_nombre.setText("Diseño y arquitectura de software");
                    ver_clave.setText("Clave: ISW202");
                    ver_semestre.setText("Semestre: 7");
                    ver_periodo.setText("Disponibilidad: Solo en otoño");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box47.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox47)
                {
                    ver_nombre.setText("Pruebas de sistemas de software");
                    ver_clave.setText("Clave: ISW205");
                    ver_semestre.setText("Semestre: 7");
                    ver_periodo.setText("Disponibilidad: Solo en otoño");
                    ver_pre.setText("Pre-requisitos: Calidad del software");
                }
            }
        });
        box48.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox48)
                {
                    ver_nombre.setText("Proceso personal de software II");
                    ver_clave.setText("Clave: ISW208");
                    ver_semestre.setText("Semestre: 7");
                    ver_periodo.setText("Disponibilidad: Solo en otoño");
                    ver_pre.setText("Pre-requisitos: Proceso personal de software I");
                }
            }
        });
        box49.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox49)
                {
                    ver_nombre.setText("Programación de dispositivos móviles");
                    ver_clave.setText("Clave: ISW211");
                    ver_semestre.setText("Semestre: 7");
                    ver_periodo.setText("Disponibilidad: Solo en otoño");
                    ver_pre.setText("Pre-requisitos: Paradigmas de programación II");
                }
            }
        });
        box50.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox50)
                {
                    ver_nombre.setText("Desarrollo web para móviles");
                    ver_clave.setText("Clave: ISW213");
                    ver_semestre.setText("Semestre: 7");
                    ver_periodo.setText("Disponibilidad: Solo en otoño");
                    ver_pre.setText("Pre-requisitos: Desarrollo web");
                }
            }
        });
        box51.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox51)
                {
                    ver_nombre.setText("Seminario de titulación");
                    ver_clave.setText("Clave: ISW401");
                    ver_semestre.setText("Semestre: 7");
                    ver_periodo.setText("Disponibilidad: Solo en otoño");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box52.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox52)
                {
                    ver_nombre.setText("Optativa (línea electiva) II");
                    ver_clave.setText("Clave: OSW002");
                    ver_semestre.setText("Semestre: 7");
                    ver_periodo.setText("Disponibilidad: Solo en otoño");
                    ver_pre.setText("Pre-requisitos: Optativa (línea electiva) I");
                }
            }
        });
        box53.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox53)
                {
                    ver_nombre.setText("Proceso de software para la industria");
                    ver_clave.setText("Clave: ISW203");
                    ver_semestre.setText("Semestre: 8");
                    ver_periodo.setText("Disponibilidad: Solo en primavera");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box54.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox54)
                {
                    ver_nombre.setText("Mantenimiento de sistemas de software");
                    ver_clave.setText("Clave: ISW206");
                    ver_semestre.setText("Semestre: 8");
                    ver_periodo.setText("Disponibilidad: Solo en primavera");
                    ver_pre.setText("Pre-requisitos: Pruebas de sistemas de software");
                }
            }
        });
        box55.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox55)
                {
                    ver_nombre.setText("Administración de proyectos y equipos de desarrollo de software");
                    ver_clave.setText("Clave: ISW209");
                    ver_semestre.setText("Semestre: 8");
                    ver_periodo.setText("Disponibilidad: Solo en primavera");
                    ver_pre.setText("Pre-requisitos: Proceso personal de software II");
                }
            }
        });
        box56.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox56)
                {
                    ver_nombre.setText("Programación avanzada de dispositivos móviles");
                    ver_clave.setText("Clave: ISW212");
                    ver_semestre.setText("Semestre: 8");
                    ver_periodo.setText("Disponibilidad: Solo en primavera");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box57.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox57)
                {
                    ver_nombre.setText("Innovación en ingeniería de software");
                    ver_clave.setText("Clave: ISW400");
                    ver_semestre.setText("Semestre: 8");
                    ver_periodo.setText("Disponibilidad: Solo en primavera");
                    ver_pre.setText("Pre-requisitos: Ninguno");
                }
            }
        });
        box58.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                if (view.getId()==R.id.checkBox58)
                {
                    ver_nombre.setText("Optativa (línea electiva) III");
                    ver_clave.setText("Clave: OSW003");
                    ver_semestre.setText("Semestre: 8");
                    ver_periodo.setText("Disponibilidad: Todos los periodos");
                    ver_pre.setText("Pre-requisitos: Optativa (línea electiva) II");
                }
            }
        });
    }
}